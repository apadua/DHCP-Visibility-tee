module github.com/apadua/dhcp-tee

go 1.22

require github.com/gopacket/gopacket v1.3.1
