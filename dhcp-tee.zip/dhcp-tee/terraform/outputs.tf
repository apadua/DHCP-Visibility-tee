output "traffic_mirror_filter_id" {
  value = aws_ec2_traffic_mirror_filter.dhcp.id
}

output "traffic_mirror_target_id" {
  value = aws_ec2_traffic_mirror_target.reformatter.id
}

output "traffic_mirror_session_ids" {
  description = "Map of Infoblox ENI -> mirror session id."
  value       = { for k, s in aws_ec2_traffic_mirror_session.infoblox : k => s.id }
}

output "reformatter_security_group_id" {
  value = aws_security_group.reformatter.id
}
