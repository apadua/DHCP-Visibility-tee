variable "vpc_id" {
  type        = string
  description = "VPC containing the Infoblox ENIs and the reformatter."
}

variable "infoblox_eni_ids" {
  type        = list(string)
  description = "ENI IDs of every DHCP-serving Infoblox member (mirror sources). Include all HA/Grid members that answer DHCP, and pick the SERVICE interface, not the management interface."
}

variable "reformatter_eni_id" {
  type        = string
  description = "ENI ID of the dhcp-tee reformatter instance (mirror target)."
}

variable "infoblox_cidr_blocks" {
  type        = list(string)
  description = "Source CIDRs allowed to send VXLAN (UDP/4789) to the reformatter — the Infoblox ENIs' subnet(s)."
}

variable "tool_cidr_blocks" {
  type        = list(string)
  description = "Destination CIDRs of the visibility tool(s) that receive relayed DHCP on UDP/67."
}
